﻿// Функционал для страницы контактов
document.addEventListener('DOMContentLoaded', function() {
    // Форма обратной связи
    const contactForm = document.querySelector('.contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Собираем данные формы
            const formData = new FormData(this);
            const data = Object.fromEntries(formData);
            
            // Валидация
            let isValid = true;
            const requiredFields = this.querySelectorAll('[required]');
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = '#F44336';
                } else {
                    field.style.borderColor = '#ddd';
                }
            });
            
            if (!isValid) {
                alert('Пожалуйста, заполните все обязательные поля');
                return;
            }
            
            // Здесь будет отправка на сервер
            console.log('Форма обратной связи:', data);
            
            // Показываем сообщение об успехе
            alert('Спасибо за ваше сообщение! Мы ответим вам в течение рабочего дня.');
            this.reset();
        });
        
        // Сбрасываем красную обводку при вводе
        const inputs = contactForm.querySelectorAll('input, textarea');
        inputs.forEach(input => {
            input.addEventListener('input', function() {
                this.style.borderColor = '#ddd';
            });
        });
    }
    
    // Имитация карты с анимацией маркера
    const mapMarker = document.querySelector('.map-marker');
    if (mapMarker) {
        setInterval(() => {
            mapMarker.style.animation = 'none';
            setTimeout(() => {
                mapMarker.style.animation = 'bounce 2s infinite';
            }, 10);
        }, 4000);
    }
    
    // Плавная прокрутка к формам при клике на контакты в хедере
    const contactLinks = document.querySelectorAll('a[href="contacts.html"]');
    contactLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // Если мы уже на странице контактов
            if (window.location.pathname.includes('contacts.html')) {
                e.preventDefault();
                document.querySelector('.contacts-form').scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Копирование email при клике
    const emails = document.querySelectorAll('a[href^="mailto:"]');
    emails.forEach(email => {
        email.addEventListener('click', function(e) {
            const emailAddress = this.href.replace('mailto:', '');
            
            // Показываем всплывающее уведомление
            const notification = document.createElement('div');
            notification.textContent = `Email ${emailAddress} скопирован в буфер обмена`;
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: #2E7D32;
                color: white;
                padding: 15px 20px;
                border-radius: 8px;
                z-index: 10000;
                animation: slideIn 0.3s ease;
            `;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => {
                    document.body.removeChild(notification);
                }, 300);
            }, 3000);
            
            // Копируем в буфер обмена
            navigator.clipboard.writeText(emailAddress).catch(err => {
                console.error('Ошибка копирования:', err);
            });
        });
    });
    
    // Добавляем стили для анимаций
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
});