﻿// Модальное окно обратного звонка
document.addEventListener('DOMContentLoaded', function() {
    // Элементы модального окна
    const modal = document.getElementById('callbackModal');
    const openButtons = document.querySelectorAll('.callback-btn');
    const closeButton = document.getElementById('closeModal');
    const form = document.querySelector('.callback-form');
    
    // Открытие модального окна
    openButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            modal.classList.add('active');
            document.body.style.overflow = 'hidden'; // Блокируем скролл
        });
    });
    
    // Закрытие модального окна
    function closeModal() {
        modal.classList.remove('active');
        document.body.style.overflow = ''; // Разблокируем скролл
    }
    
    // Закрытие по кнопке
    if (closeButton) {
        closeButton.addEventListener('click', closeModal);
    }
    
    // Закрытие по клику на оверлей
    modal.addEventListener('click', function(e) {
        if (e.target === modal || e.target.classList.contains('modal__overlay')) {
            closeModal();
        }
    });
    
    // Закрытие по Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && modal.classList.contains('active')) {
            closeModal();
        }
    });
    
    // Обработка формы
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Собираем данные формы
            const formData = new FormData(form);
            const data = Object.fromEntries(formData);
            
            // Здесь будет отправка на сервер
            console.log('Данные формы:', data);
            
            // Показываем сообщение об успехе
            alert('Спасибо! Мы скоро вам перезвоним.');
            closeModal();
            form.reset();
        });
    }
    
    // Плавная прокрутка для якорных ссылок
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            // Если это не якорная ссылка, ничего не делаем
            if (href === '#' || href.startsWith('#!')) return;
            
            // Если это ссылка на другую страницу с якорем, разрешаем обычный переход
            if (href.includes('.html')) return;
            
            e.preventDefault();
            
            const targetId = href.substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                const headerHeight = document.querySelector('.header').offsetHeight;
                const targetPosition = targetElement.offsetTop - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Активное состояние меню при скролле
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav__link');
    
    function updateActiveNavLink() {
        let current = '';
        const scrollPosition = window.scrollY + 100;
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            
            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            const href = link.getAttribute('href');
            
            if (href === `#${current}` || 
                (current === '' && href === 'index.html') ||
                (current && href.includes(`#${current}`))) {
                link.classList.add('active');
            }
        });
    }
    
    window.addEventListener('scroll', updateActiveNavLink);
    
    // Инициализация при загрузке
    updateActiveNavLink();
    
    // Подсветка кнопок при наведении
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
        });
        
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
});