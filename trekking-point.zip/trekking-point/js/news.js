﻿// Функционал для страницы новостей
document.addEventListener('DOMContentLoaded', function() {
    // Фильтр новостей
    const filterButtons = document.querySelectorAll('.news-filter__btn');
    const newsItems = document.querySelectorAll('.news-item');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Убираем активный класс у всех кнопок
            filterButtons.forEach(btn => btn.classList.remove('active'));
            // Добавляем активный класс текущей кнопке
            this.classList.add('active');
            
            const filter = this.textContent;
            
            // Показываем/скрываем новости
            newsItems.forEach(item => {
                const category = item.querySelector('.news-item__category').textContent;
                
                if (filter === 'Все новости' || category === filter) {
                    item.style.display = 'grid';
                    setTimeout(() => {
                        item.style.opacity = '1';
                        item.style.transform = 'translateY(0)';
                    }, 10);
                } else {
                    item.style.opacity = '0';
                    item.style.transform = 'translateY(20px)';
                    setTimeout(() => {
                        item.style.display = 'none';
                    }, 300);
                }
            });
        });
    });
    
    // Поиск по новостям
    const searchForm = document.querySelector('.search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const searchInput = this.querySelector('.search-input');
            const searchTerm = searchInput.value.toLowerCase();
            
            if (searchTerm.trim() === '') {
                // Показываем все новости если поиск пустой
                newsItems.forEach(item => {
                    item.style.display = 'grid';
                });
                return;
            }
            
            // Фильтруем новости
            newsItems.forEach(item => {
                const title = item.querySelector('.news-item__title').textContent.toLowerCase();
                const excerpt = item.querySelector('.news-item__excerpt').textContent.toLowerCase();
                
                if (title.includes(searchTerm) || excerpt.includes(searchTerm)) {
                    item.style.display = 'grid';
                    setTimeout(() => {
                        item.style.opacity = '1';
                        item.style.transform = 'translateY(0)';
                    }, 10);
                } else {
                    item.style.opacity = '0';
                    item.style.transform = 'translateY(20px)';
                    setTimeout(() => {
                        item.style.display = 'none';
                    }, 300);
                }
            });
        });
    }
    
    // Подписка на рассылку
    const subscribeForm = document.querySelector('.subscribe-form');
    if (subscribeForm) {
        subscribeForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const emailInput = this.querySelector('.subscribe-input');
            const email = emailInput.value;
            
            if (email.trim() === '') {
                alert('Пожалуйста, введите email');
                return;
            }
            
            if (!validateEmail(email)) {
                alert('Пожалуйста, введите корректный email');
                return;
            }
            
            // Здесь будет отправка на сервер
            console.log('Подписка на рассылку:', email);
            
            // Показываем сообщение об успехе
            alert('Спасибо за подписку! Проверьте вашу почту для подтверждения.');
            emailInput.value = '';
        });
    }
    
    // Валидация email
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    // Анимация появления новостей при скролле
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Применяем анимацию к новостям
    newsItems.forEach(item => {
        item.style.opacity = '0';
        item.style.transform = 'translateY(20px)';
        item.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        observer.observe(item);
    });
});