﻿// Функционал для страницы тура
document.addEventListener('DOMContentLoaded', function() {
    // Табы
    const tabButtons = document.querySelectorAll('.tour-tabs__btn');
    const tabContents = document.querySelectorAll('.tour-tab');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            // Убираем активный класс у всех кнопок и контента
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Добавляем активный класс текущим элементам
            this.classList.add('active');
            document.getElementById(tabId).classList.add('active');
        });
    });
    
    // Счётчик количества человек
    const minusBtn = document.querySelector('.counter-btn.minus');
    const plusBtn = document.querySelector('.counter-btn.plus');
    const counterInput = document.querySelector('.counter-input');
    const priceElement = document.querySelector('.price-current');
    
    if (minusBtn && plusBtn && counterInput) {
        const basePrice = 25000;
        
        minusBtn.addEventListener('click', function() {
            let value = parseInt(counterInput.value);
            if (value > 1) {
                counterInput.value = value - 1;
                updatePrice();
            }
        });
        
        plusBtn.addEventListener('click', function() {
            let value = parseInt(counterInput.value);
            if (value < 8) {
                counterInput.value = value + 1;
                updatePrice();
            }
        });
        
        counterInput.addEventListener('change', function() {
            let value = parseInt(this.value);
            if (value < 1) this.value = 1;
            if (value > 8) this.value = 8;
            updatePrice();
        });
        
        function updatePrice() {
            const count = parseInt(counterInput.value);
            const total = basePrice * count;
            
            // Обновляем итоговую сумму
            const totalElement = document.querySelector('.summary-row.total span:last-child');
            if (totalElement) {
                totalElement.textContent = total.toLocaleString('ru-RU') + ' ₽';
            }
            
            // Обновляем количество в сводке
            const countElement = document.querySelector('.summary-row:nth-child(2) span:last-child');
            if (countElement) {
                countElement.textContent = count + ' чел.';
            }
        }
    }
    
    // Форма бронирования
    const bookingForm = document.querySelector('.booking-form__content');
    if (bookingForm) {
        bookingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Собираем данные формы
            const formData = new FormData(this);
            const data = Object.fromEntries(formData);
            
            // Здесь будет отправка на сервер
            console.log('Бронирование тура:', data);
            
            // Показываем сообщение об успехе
            alert('Спасибо за бронирование! Мы свяжемся с вами в течение часа для подтверждения.');
            this.reset();
            counterInput.value = 1;
            updatePrice();
        });
    }
    
    // FAQ
    const faqQuestions = document.querySelectorAll('.faq-question');
    faqQuestions.forEach(question => {
        question.addEventListener('click', function() {
            const answer = this.nextElementSibling;
            const isActive = this.classList.contains('active');
            
            // Закрываем все остальные
            faqQuestions.forEach(q => {
                q.classList.remove('active');
                q.nextElementSibling.classList.remove('active');
            });
            
            // Открываем текущий, если был закрыт
            if (!isActive) {
                this.classList.add('active');
                answer.classList.add('active');
            }
        });
    });
    
    // Кнопка "Забронировать сейчас"
    const bookNowBtn = document.querySelector('.book-now-btn');
    if (bookNowBtn) {
        bookNowBtn.addEventListener('click', function() {
            // Прокручиваем к форме бронирования
            document.querySelector('.booking-form').scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        });
    }
});